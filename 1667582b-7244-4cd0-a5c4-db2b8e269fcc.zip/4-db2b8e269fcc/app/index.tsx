import { Text, View, StyleSheet, TouchableOpacity, ScrollView, Platform } from 'react-native';
import { router } from 'expo-router';
import { useState, useEffect } from 'react';
import { MaterialIcons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import { useFonts, OpenSans_400Regular, OpenSans_600SemiBold, OpenSans_700Bold } from '@expo-google-fonts/open-sans';
import { commonStyles, colors } from '../styles/commonStyles';

interface Bicycle {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  distance: number;
  batteryLevel?: number;
  type: 'electric' | 'manual';
  available: boolean;
}

export default function HomeScreen() {
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [bicycles, setBicycles] = useState<Bicycle[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'map' | 'list'>('list');

  let [fontsLoaded] = useFonts({
    OpenSans_400Regular,
    OpenSans_600SemiBold,
    OpenSans_700Bold,
  });

  useEffect(() => {
    getLocationPermission();
    loadMockBicycles();
  }, []);

  const getLocationPermission = async () => {
    try {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.log('Permission to access location was denied');
        setLoading(false);
        return;
      }

      let currentLocation = await Location.getCurrentPositionAsync({});
      setLocation(currentLocation);
      console.log('Current location:', currentLocation.coords);
    } catch (error) {
      console.log('Error getting location:', error);
    }
    setLoading(false);
  };

  const loadMockBicycles = () => {
    // Mock data for demonstration - in real app this would come from API
    const mockBicycles: Bicycle[] = [
      {
        id: '1',
        name: 'City Bike #001',
        latitude: 40.7589,
        longitude: -73.9851,
        distance: 0.2,
        batteryLevel: 85,
        type: 'electric',
        available: true,
      },
      {
        id: '2',
        name: 'City Bike #002',
        latitude: 40.7614,
        longitude: -73.9776,
        distance: 0.5,
        type: 'manual',
        available: true,
      },
      {
        id: '3',
        name: 'City Bike #003',
        latitude: 40.7505,
        longitude: -73.9934,
        distance: 0.8,
        batteryLevel: 65,
        type: 'electric',
        available: false,
      },
      {
        id: '4',
        name: 'City Bike #004',
        latitude: 40.7580,
        longitude: -73.9855,
        distance: 1.2,
        type: 'manual',
        available: true,
      },
    ];

    // Sort by distance
    mockBicycles.sort((a, b) => a.distance - b.distance);
    setBicycles(mockBicycles);
  };

  const handleBicyclePress = (bicycle: Bicycle) => {
    router.push({
      pathname: '/bicycle/[id]',
      params: { 
        id: bicycle.id,
        name: bicycle.name,
        latitude: bicycle.latitude.toString(),
        longitude: bicycle.longitude.toString(),
        distance: bicycle.distance.toString(),
        batteryLevel: bicycle.batteryLevel?.toString() || '',
        type: bicycle.type,
        available: bicycle.available.toString(),
      }
    });
  };

  const renderBicycleCard = (bicycle: Bicycle, index: number) => (
    <Animated.View
      key={bicycle.id}
      entering={FadeInDown.delay(index * 100).springify()}
    >
      <TouchableOpacity
        style={[styles.bicycleCard, !bicycle.available && styles.unavailableCard]}
        onPress={() => handleBicyclePress(bicycle)}
        activeOpacity={0.7}
      >
        <View style={styles.cardHeader}>
          <View style={styles.bicycleInfo}>
            <MaterialIcons
              name={bicycle.type === 'electric' ? 'electric-bike' : 'pedal-bike'}
              size={24}
              color={bicycle.available ? colors.accent : colors.grey}
            />
            <Text style={[styles.bicycleName, !bicycle.available && styles.unavailableText]}>
              {bicycle.name}
            </Text>
          </View>
          <View style={styles.statusContainer}>
            <Text style={[styles.distance, !bicycle.available && styles.unavailableText]}>
              {bicycle.distance.toFixed(1)} km
            </Text>
            <View style={[
              styles.statusBadge,
              bicycle.available ? styles.availableBadge : styles.unavailableBadge
            ]}>
              <Text style={styles.statusText}>
                {bicycle.available ? 'Available' : 'In Use'}
              </Text>
            </View>
          </View>
        </View>
        
        {bicycle.batteryLevel && (
          <View style={styles.batteryContainer}>
            <MaterialIcons name="battery-std" size={16} color={colors.accent} />
            <Text style={styles.batteryText}>{bicycle.batteryLevel}% battery</Text>
          </View>
        )}
        
        <View style={styles.cardFooter}>
          <MaterialIcons name="location-on" size={14} color={colors.grey} />
          <Text style={styles.locationText}>
            {bicycle.latitude.toFixed(4)}, {bicycle.longitude.toFixed(4)}
          </Text>
        </View>
      </TouchableOpacity>
    </Animated.View>
  );

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={commonStyles.wrapper}>
      <Animated.View entering={FadeInUp.springify()} style={styles.header}>
        <Text style={styles.headerTitle}>BikeShare</Text>
        <Text style={styles.headerSubtitle}>Find nearby bicycles</Text>
        
        <View style={styles.viewToggle}>
          <TouchableOpacity
            style={[styles.toggleButton, viewMode === 'list' && styles.activeToggle]}
            onPress={() => setViewMode('list')}
          >
            <MaterialIcons name="list" size={20} color={viewMode === 'list' ? '#fff' : colors.grey} />
            <Text style={[styles.toggleText, viewMode === 'list' && styles.activeToggleText]}>
              List
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.toggleButton, viewMode === 'map' && styles.activeToggle]}
            onPress={() => setViewMode('map')}
          >
            <MaterialIcons name="map" size={20} color={viewMode === 'map' ? '#fff' : colors.grey} />
            <Text style={[styles.toggleText, viewMode === 'map' && styles.activeToggleText]}>
              Map
            </Text>
          </TouchableOpacity>
        </View>
      </Animated.View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <MaterialIcons name="location-searching" size={48} color={colors.accent} />
          <Text style={styles.loadingText}>Finding your location...</Text>
        </View>
      ) : viewMode === 'map' ? (
        <View style={styles.mapPlaceholder}>
          <MaterialIcons name="map" size={64} color={colors.grey} />
          <Text style={styles.mapPlaceholderText}>
            Maps are not supported on web in Natively.
          </Text>
          <Text style={styles.mapPlaceholderSubtext}>
            Switch to mobile app for map view with react-native-maps.
          </Text>
        </View>
      ) : (
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>{bicycles.filter(b => b.available).length}</Text>
              <Text style={styles.statLabel}>Available</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>{bicycles.length}</Text>
              <Text style={styles.statLabel}>Total Nearby</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>
                {bicycles.length > 0 ? bicycles[0].distance.toFixed(1) : '0.0'}
              </Text>
              <Text style={styles.statLabel}>Closest (km)</Text>
            </View>
          </View>

          <View style={styles.listHeader}>
            <Text style={styles.listTitle}>Nearby Bicycles</Text>
            <Text style={styles.listSubtitle}>Sorted by distance</Text>
          </View>

          {bicycles.map((bicycle, index) => renderBicycleCard(bicycle, index))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
    backgroundColor: colors.background,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'OpenSans_700Bold',
    color: colors.text,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'OpenSans_400Regular',
    color: colors.grey,
    marginBottom: 20,
  },
  viewToggle: {
    flexDirection: 'row',
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 4,
  },
  toggleButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    borderRadius: 8,
  },
  activeToggle: {
    backgroundColor: colors.primary,
  },
  toggleText: {
    marginLeft: 4,
    fontSize: 14,
    fontFamily: 'OpenSans_600SemiBold',
    color: colors.grey,
  },
  activeToggleText: {
    color: '#fff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    fontFamily: 'OpenSans_400Regular',
    color: colors.text,
  },
  mapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  mapPlaceholderText: {
    marginTop: 16,
    fontSize: 18,
    fontFamily: 'OpenSans_600SemiBold',
    color: colors.text,
    textAlign: 'center',
  },
  mapPlaceholderSubtext: {
    marginTop: 8,
    fontSize: 14,
    fontFamily: 'OpenSans_400Regular',
    color: colors.grey,
    textAlign: 'center',
    lineHeight: 20,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    marginBottom: 24,
    backgroundColor: colors.backgroundAlt,
    borderRadius: 16,
    padding: 16,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontFamily: 'OpenSans_700Bold',
    color: colors.accent,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'OpenSans_400Regular',
    color: colors.grey,
    textAlign: 'center',
  },
  listHeader: {
    marginBottom: 16,
  },
  listTitle: {
    fontSize: 20,
    fontFamily: 'OpenSans_600SemiBold',
    color: colors.text,
    marginBottom: 4,
  },
  listSubtitle: {
    fontSize: 14,
    fontFamily: 'OpenSans_400Regular',
    color: colors.grey,
  },
  bicycleCard: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.primary,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.15)',
    elevation: 4,
  },
  unavailableCard: {
    opacity: 0.6,
    borderColor: colors.grey,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  bicycleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  bicycleName: {
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'OpenSans_600SemiBold',
    color: colors.text,
    flex: 1,
  },
  unavailableText: {
    color: colors.grey,
  },
  statusContainer: {
    alignItems: 'flex-end',
  },
  distance: {
    fontSize: 14,
    fontFamily: 'OpenSans_600SemiBold',
    color: colors.accent,
    marginBottom: 4,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  availableBadge: {
    backgroundColor: '#4CAF50',
  },
  unavailableBadge: {
    backgroundColor: '#FF9800',
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'OpenSans_600SemiBold',
    color: '#fff',
  },
  batteryContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  batteryText: {
    marginLeft: 6,
    fontSize: 14,
    fontFamily: 'OpenSans_400Regular',
    color: colors.accent,
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    marginLeft: 4,
    fontSize: 12,
    fontFamily: 'OpenSans_400Regular',
    color: colors.grey,
  },
});