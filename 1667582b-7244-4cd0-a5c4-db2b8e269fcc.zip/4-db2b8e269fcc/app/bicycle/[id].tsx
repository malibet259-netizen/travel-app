import { Text, View, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import { useFonts, OpenSans_400Regular, OpenSans_600SemiBold, OpenSans_700Bold } from '@expo-google-fonts/open-sans';
import { colors } from '../../styles/commonStyles';
import Button from '../../components/Button';

export default function BicycleDetailScreen() {
  const params = useLocalSearchParams();
  const {
    id,
    name,
    latitude,
    longitude,
    distance,
    batteryLevel,
    type,
    available,
  } = params;

  let [fontsLoaded] = useFonts({
    OpenSans_400Regular,
    OpenSans_600SemiBold,
    OpenSans_700Bold,
  });

  const handleReserveBicycle = () => {
    if (available === 'true') {
      Alert.alert(
        'Reserve Bicycle',
        `Would you like to reserve ${name}?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Reserve',
            onPress: () => {
              Alert.alert('Success', 'Bicycle reserved for 15 minutes!');
            },
          },
        ]
      );
    } else {
      Alert.alert('Unavailable', 'This bicycle is currently in use.');
    }
  };

  const handleGetDirections = () => {
    Alert.alert(
      'Directions',
      'In a real app, this would open directions to the bicycle location.',
      [{ text: 'OK' }]
    );
  };

  if (!fontsLoaded) {
    return null;
  }

  const isAvailable = available === 'true';
  const isElectric = type === 'electric';

  return (
    <View style={styles.container}>
      <Animated.View entering={FadeInUp.springify()} style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
          activeOpacity={0.7}
        >
          <MaterialIcons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Bicycle Details</Text>
      </Animated.View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <Animated.View entering={FadeInDown.delay(100).springify()} style={styles.heroCard}>
          <View style={styles.bicycleHeader}>
            <MaterialIcons
              name={isElectric ? 'electric-bike' : 'pedal-bike'}
              size={48}
              color={isAvailable ? colors.accent : colors.grey}
            />
            <View style={styles.bicycleInfo}>
              <Text style={[styles.bicycleName, !isAvailable && styles.unavailableText]}>
                {name}
              </Text>
              <View style={[
                styles.statusBadge,
                isAvailable ? styles.availableBadge : styles.unavailableBadge
              ]}>
                <Text style={styles.statusText}>
                  {isAvailable ? 'Available' : 'In Use'}
                </Text>
              </View>
            </View>
          </View>

          {isElectric && batteryLevel && (
            <View style={styles.batterySection}>
              <MaterialIcons name="battery-std" size={24} color={colors.accent} />
              <View style={styles.batteryInfo}>
                <Text style={styles.batteryText}>{batteryLevel}% Battery</Text>
                <View style={styles.batteryBar}>
                  <View
                    style={[
                      styles.batteryFill,
                      { width: `${batteryLevel}%` },
                      parseInt(batteryLevel) > 50 ? styles.batteryHigh : 
                      parseInt(batteryLevel) > 20 ? styles.batteryMedium : styles.batteryLow
                    ]}
                  />
                </View>
              </View>
            </View>
          )}
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(200).springify()} style={styles.detailsCard}>
          <Text style={styles.sectionTitle}>Location Details</Text>
          
          <View style={styles.detailRow}>
            <MaterialIcons name="location-on" size={20} color={colors.accent} />
            <View style={styles.detailContent}>
              <Text style={styles.detailLabel}>Coordinates</Text>
              <Text style={styles.detailValue}>
                {parseFloat(latitude as string).toFixed(4)}, {parseFloat(longitude as string).toFixed(4)}
              </Text>
            </View>
          </View>

          <View style={styles.detailRow}>
            <MaterialIcons name="near-me" size={20} color={colors.accent} />
            <View style={styles.detailContent}>
              <Text style={styles.detailLabel}>Distance</Text>
              <Text style={styles.detailValue}>{distance} km away</Text>
            </View>
          </View>

          <View style={styles.detailRow}>
            <MaterialIcons name={isElectric ? 'electric-bike' : 'pedal-bike'} size={20} color={colors.accent} />
            <View style={styles.detailContent}>
              <Text style={styles.detailLabel}>Type</Text>
              <Text style={styles.detailValue}>
                {isElectric ? 'Electric Bike' : 'Manual Bike'}
              </Text>
            </View>
          </View>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(300).springify()} style={styles.actionsCard}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          
          <Button
            text={isAvailable ? 'Reserve Bicycle' : 'Currently Unavailable'}
            onPress={handleReserveBicycle}
            style={[
              styles.actionButton,
              !isAvailable && styles.disabledButton
            ]}
            textStyle={!isAvailable ? styles.disabledButtonText : undefined}
          />
          
          <Button
            text="Get Directions"
            onPress={handleGetDirections}
            style={[styles.actionButton, styles.secondaryButton]}
            textStyle={styles.secondaryButtonText}
          />
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(400).springify()} style={styles.infoCard}>
          <Text style={styles.sectionTitle}>Important Information</Text>
          <View style={styles.infoItem}>
            <MaterialIcons name="info" size={16} color={colors.accent} />
            <Text style={styles.infoText}>
              Reservations are held for 15 minutes
            </Text>
          </View>
          <View style={styles.infoItem}>
            <MaterialIcons name="schedule" size={16} color={colors.accent} />
            <Text style={styles.infoText}>
              Service available 24/7
            </Text>
          </View>
          <View style={styles.infoItem}>
            <MaterialIcons name="security" size={16} color={colors.accent} />
            <Text style={styles.infoText}>
              Always wear a helmet for safety
            </Text>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    backgroundColor: colors.background,
  },
  backButton: {
    padding: 4,
    marginRight: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'OpenSans_700Bold',
    color: colors.text,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  heroCard: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.primary,
    boxShadow: '0px 6px 16px rgba(0, 0, 0, 0.2)',
    elevation: 6,
  },
  bicycleHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  bicycleInfo: {
    marginLeft: 16,
    flex: 1,
  },
  bicycleName: {
    fontSize: 24,
    fontFamily: 'OpenSans_700Bold',
    color: colors.text,
    marginBottom: 8,
  },
  unavailableText: {
    color: colors.grey,
  },
  statusBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  availableBadge: {
    backgroundColor: '#4CAF50',
  },
  unavailableBadge: {
    backgroundColor: '#FF9800',
  },
  statusText: {
    fontSize: 14,
    fontFamily: 'OpenSans_600SemiBold',
    color: '#fff',
  },
  batterySection: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: colors.primary,
  },
  batteryInfo: {
    marginLeft: 12,
    flex: 1,
  },
  batteryText: {
    fontSize: 16,
    fontFamily: 'OpenSans_600SemiBold',
    color: colors.accent,
    marginBottom: 8,
  },
  batteryBar: {
    height: 8,
    backgroundColor: colors.background,
    borderRadius: 4,
    overflow: 'hidden',
  },
  batteryFill: {
    height: '100%',
    borderRadius: 4,
  },
  batteryHigh: {
    backgroundColor: '#4CAF50',
  },
  batteryMedium: {
    backgroundColor: '#FF9800',
  },
  batteryLow: {
    backgroundColor: '#F44336',
  },
  detailsCard: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'OpenSans_600SemiBold',
    color: colors.text,
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  detailContent: {
    marginLeft: 12,
    flex: 1,
  },
  detailLabel: {
    fontSize: 14,
    fontFamily: 'OpenSans_400Regular',
    color: colors.grey,
    marginBottom: 2,
  },
  detailValue: {
    fontSize: 16,
    fontFamily: 'OpenSans_600SemiBold',
    color: colors.text,
  },
  actionsCard: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  actionButton: {
    marginBottom: 12,
  },
  disabledButton: {
    backgroundColor: colors.grey,
    opacity: 0.6,
  },
  disabledButtonText: {
    color: colors.background,
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: colors.accent,
  },
  secondaryButtonText: {
    color: colors.accent,
  },
  infoCard: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoText: {
    marginLeft: 8,
    fontSize: 14,
    fontFamily: 'OpenSans_400Regular',
    color: colors.text,
    flex: 1,
  },
});